<?php

/*
@name     OpenCart
@package  Library Decorator
@author   Andrii Burkatskyi aka 4ndr116, <ocmod.space@gmail.com>
@version  1.0.0
@link     https://github.com/ocmod-space/ocmod-library-decorator
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/ocmod-library-decorator
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-library-decorator/main/LICENSE.txt
*/

namespace Opencart\Admin\Controller\Extension\LibraryDecorator\Module;
class LibraryDecorator extends \Opencart\System\Engine\Controller {
	private $mod;
	private $lib;
	private $cfg;

	private $error = [];

	/**
	 * @param mixed $registry
	 */
	public function __construct(\Opencart\System\Engine\Registry $registry) {
		parent::__construct($registry);

		$name = pathinfo(__FILE__, PATHINFO_FILENAME);

		require_once DIR_EXTENSION . "{$name}/system/library/ocmod_space/{$name}/module.php";
		$this->mod = new \OcmodSpace\LibraryDecorator\Module($registry);

		$this->cfg = $this->mod->config();
	}

	/**
	 * Index.
	 *
	 * @return void
	 */
	public function index(): void {
		$this->load->language($this->mod->route());

		$token = 'user_token=' . $this->session->data['user_token'];
		$extension_route = 'marketplace/extension';

		$heading_title = strip_tags($this->language->get('heading_title'));
		$this->document->setTitle($heading_title);

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->uninstallEvents();

			if (!empty($this->request->post["{$this->mod->tag()}_status"])) {
				$this->installEvents();
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting($this->mod->tag(), $this->request->post);

			if (!isset($this->request->get['apply'])) {
				$redirect_to = $this->url->link($extension_route, "{$token}&type={$this->mod->type()}", true);
			} else {
				$redirect_to = $this->url->link($this->mod->route(), "{$token}&type={$this->mod->type()}", true);
			}

			$this->response->redirect($redirect_to);
		}

		if (!empty($this->error)) {
			foreach ($this->error as $key => $value) {
				$data['error'][$key] = $value;
			}
		} else {
			$data['error'] = [];
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', $token, true),
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link($extension_route, "{$token}&type={$this->mod->type()}", true),
		];

		$data['breadcrumbs'][] = [
			'text' => 'Library Decorator',
			'href' => $this->url->link($this->mod->route(), $token, true),
		];

		$data['action'] = $this->url->link($this->mod->route(), $token, true);
		$data['apply'] = $this->url->link($this->mod->route(), "{$token}&apply=1", true);
		$data['cancel'] = $this->url->link($extension_route, "{$token}&type={$this->mod->type()}", true);
		$data['module'] = $this->mod->tag();

		if (isset($this->request->post["{$this->mod->tag()}_status"])) {
			$data['status'] = $this->request->post["{$this->mod->tag()}_status"];
		} else {
			$data['status'] = $this->mod->status();
		}

		$this->load->model('localisation/language');
		$data['languages'] = $this->model_localisation_language->getLanguages();

		$data['stores'] = [];

		$this->load->model('setting/store');

		foreach ($this->model_setting_store->getStores() as $store) {
			$data['stores'][] = [
				'store_id' => $store['store_id'],
				'name'     => $store['name'],
			];
		}

		$default_store = [
			'store_id' => 0,
			'name'     => $this->config->get('config_name') . strip_tags($this->language->get('text_default')),
		];

		array_unshift($data['stores'], $default_store);

		$settings_path = "library/ocmod_space/{$this->mod->name()}/settings.php";
		include DIR_EXTENSION . "{$this->mod->name()}/system/{$settings_path}";

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view($this->mod->route(), $data));
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$this->uninstall();

		$this->load->model('user/user_group');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $this->mod->route());
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $this->mod->route());
	}

	/**
	 * @return void
	 */
	private function installEvents(): void {
		$event_route = 'setting/event';
		$event_model = 'model_setting_event';
		$this->load->model($event_route);

		$div = version_compare(VERSION, '4.0.0.0', '<') ? '/' : (version_compare(VERSION, '4.0.2.0', '<') ? '|' : '.');

		$event_code = "{$this->mod->name()}_admin";

		$library_path = "library/ocmod_space/{$this->mod->name()}/library";
		include DIR_EXTENSION . "{$this->mod->name()}/system/{$library_path}";

		$trigger = 'admin/view/design/layout_form/before';
		$action = "{$this->mod->route()}{$div}beforeViewDesignLayoutForm";
		$description = 'Hiding the module in the layout design form.';
		$this->{$event_model}->addEvent($this->event_data($event_code, $trigger, $action, $description));

		$trigger = 'admin/controller/*/before';
		$action = "{$this->mod->route()}{$div}libraryDecorator";
		$description = 'Replacing the Cart class with a decorated version for the backend calls.';
		$this->{$event_model}->addEvent($this->event_data($event_code, $trigger, $action, $description));

		$event_code = "{$this->mod->name()}_catalog";

		$trigger = 'catalog/model/*/before';
		$action = "{$this->mod->route()}{$div}libraryDecorator";
		$description = 'Replacing the Cart class with a decorated version for the frontend calls.';
		$this->{$event_model}->addEvent($this->event_data($event_code, $trigger, $action, $description));

		$trigger = 'catalog/controller/*/before';
		$action = "{$this->mod->route()}{$div}libraryDecorator";
		$description = 'Replacing the Cart class with a decorated version for the frontend calls.';
		$this->{$event_model}->addEvent($this->event_data($event_code, $trigger, $action, $description));
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		$this->uninstallEvents();

		if (!empty($this->cfg['cleanout'])) {
			$this->load->model($this->mod->route());
		}

		$this->load->model('user/user_group');
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', $this->mod->route());
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', $this->mod->route());
	}

	/**
	 * @return void
	 */
	private function uninstallEvents(): void {
		$event_route = 'setting/event';
		$event_model = 'model_setting_event';
		$delete_method = 'deleteEventByCode';

		$this->load->model($event_route);

		$event_codes = [
			"{$this->mod->name()}_admin",
			"{$this->mod->name()}_catalog",
		];

		foreach ($event_codes as $event_code) {
			$this->{$event_model}->{$delete_method}($event_code);
		}
	}

	/**
	 * Checking permissions.
	 *
	 * @return bool
	 */
	protected function validate(): bool {
		$this->load->model('user/user_group');

		if (!$this->user->hasPermission('modify', $this->mod->route())) {
			$this->error['permission'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	/**
	 * Getting event data array. (OpenCart 4.x.x.x only).
	 *
	 * @param string $code
	 * @param string $trigger
	 * @param string $action
	 * @param string $description
	 * @param int    $status
	 * @param int    $sort_order
	 *
	 * @return array
	 */
	private function event_data(
		string $code,
		string $trigger,
		string $action,
		string $description = '',
		int $status = 1,
		int $sort_order = 0
	): array {
		return [
			'code'        => $code,
			'trigger'     => $trigger,
			'action'      => $action,
			'description' => $description ?: $action,
			'status'      => $status,
			'sort_order'  => $sort_order
		];
	}

	/**
	 * https://forum.opencart.com/viewtopic.php?p=799279#p799279.
	 *
	 * @param string $route
	 * @param array  $data
	 *
	 * @return void
	 */
	public function beforeViewDesignLayoutForm(string &$route, array &$data): void {
		foreach ($data['extensions'] as $key => $extension) {
			if (str_contains($extension['code'], $this->mod->name())) {
				unset($data['extensions'][$key]);
			}
		}
	}

	/**
	 * @param string $route
	 * @param mixed  $data
	 *
	 * @return void
	 */
	public function libraryDecorator(string &$route, &$data): void {
		if (!$this->mod->status()) {
			return;
		}

		$path_suffix = "library/ocmod_space/{$this->mod->name()}";
		require_once(DIR_EXTENSION . "{$this->mod->name()}/system/{$path_suffix}/abstract_decorator.php");

		$map = [
			'cart' => \OcmodSpace\LibraryDecorator\CartDecorator::class,
			'tax'  => \OcmodSpace\LibraryDecorator\TaxDecorator::class,
		];

		foreach ($map as $key => $class) {
			$file = DIR_EXTENSION . "{$this->mod->name()}/system/{$path_suffix}/" . strtolower($key) . '_decorator.php';

			if (is_file($file)) {
				require_once($file);
			}

			if (!($this->registry->get($key) instanceof $class)) {
				$this->registry->set($key, new $class($this->registry));
			}
		}
	}
}
