<?php

/*
@name     OpenCart
@package  Library Decorator
@author   Andrii Burkatskyi aka 4ndr116, <ocmod.space@gmail.com>
@version  1.0.0
@link     https://github.com/ocmod-space/ocmod-library-decorator
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/ocmod-library-decorator
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-library-decorator/main/LICENSE.txt
*/

$_['heading_title'] = '/<a href="https://www.ocmod.space/">ocmod.space</a>/library_decorator';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit <b>Library Decorator</b>';
$_['text_success'] = 'Success! The <b>Library Decorator</b> module settings have been saved.';
$_['error_permission'] = 'WARNING! You do not have write permissions for the module <b>Library Decorator</b>.';
$_['text_made'] = '<code>Made with <i class="fa fa-heart" aria-hidden="true" style="background: linear-gradient(to bottom, #0057b7 50%, #ffd700 50%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-size: 18px;"></i> in Ukraine</code>';
$_['text_about'] = 'A library decorator to catch <code>cart</code>- and <code>tax</code>-related events and to add custom functionality.';

$_['entry_status'] = 'Status';
