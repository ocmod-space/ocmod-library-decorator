<?php

/*
@name     OpenCart
@package  Library Decorator
@author   excodius (ocmod.space), <ocmod.space@gmail.com>
@version  1.0.0
@link     https://github.com/ocmod-space/ocmod-library-decorator
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/ocmod-library-decorator
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-library-decorator/main/LICENSE.txt
*/

namespace OcmodSpace\LibraryDecorator;

abstract class AbstractDecorator {
	protected $registry;
	protected $event;
	protected $db;
	protected $instance;
	protected $trigger_prefix;

	private $events_loaded = false;
	private $div;

	/**
	 * @param mixed  $registry
	 * @param string $class
	 * @param string $trigger_prefix
	 */
	public function __construct($registry, string $class, string $trigger_prefix) {
		$this->registry = $registry;
		$this->db = $registry->get('db');
		$this->event = $registry->get('event');
		$this->trigger_prefix = $trigger_prefix;

		$this->div = version_compare(VERSION, '4.0.0.0', '<') ? '/' : (version_compare(VERSION, '4.0.2.0', '<') ? '|' : '.');

		$class = '\\' . $class;

		if (!class_exists($class)) {
			throw new \Exception('Error: Class ' . $class . ' not found!');
		}

		$this->instance = new $class($registry);
	}

	/**
	 * @param string $method
	 * @param mixed  $args
	 *
	 * @return mixed
	 */
	public function __call(string $method, $args) {
		if (!$this->events_loaded) {
			$this->loadEvents();
			$this->events_loaded = true;
		}

		$method = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$method);
		$trigger = $this->trigger_prefix . $this->div . $method;

		$result = $this->event->trigger($trigger . '/before', [&$method, &$args]);

		if (is_array($result) && !empty($result)) {
			$output = end($result); // The last value is returned by events
		} else {
			$output = call_user_func_array([$this->instance, $method], $args);
		}

		$result = $this->event->trigger($trigger . '/after', [&$method, &$args, &$output]);

		if (is_array($result) && !empty($result)) {
			$last = end($result);
			if (gettype($last) === gettype($output)) {
				$output = $last;
			}
		}

		return $output;
	}

	/**
	 * @return void
	 */
	protected function loadEvents(): void {
		$query = $this->db->query(
			"SELECT
				* FROM `" . DB_PREFIX . "event`
			WHERE
				`trigger` LIKE '" . $this->db->escape($this->trigger_prefix) . $this->div . "%'"
		);

		foreach ($query->rows as $row) {
			if (!isset($this->event->data[$row['trigger']])) {
				$this->event->register($row['trigger'], new \Opencart\System\Engine\Action($row['action']));
			}
		}
	}
}
