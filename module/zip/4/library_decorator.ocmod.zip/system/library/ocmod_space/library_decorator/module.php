<?php

/*
@name     OpenCart
@package  Library Decorator
@author   excodius (ocmod.space), <ocmod.space@gmail.com>
@version  1.0.0
@link     https://github.com/ocmod-space/ocmod-library-decorator
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/ocmod-library-decorator
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-library-decorator/main/LICENSE.txt
*/

namespace OcmodSpace\LibraryDecorator;

class Module {
	private const TYPE = 'module';
	private const NAME = 'library_decorator';

	private $config;

	public function __construct(\Opencart\System\Engine\Registry $registry) {
		$this->config = $registry->get('config');
	}

	/**
	 * @return string
	 */
	public function type(): string {
		return self::TYPE;
	}

	/**
	 * @return string
	 */
	public function name(): string {
		return self::NAME;
	}

	/**
	 * @return string
	 */
	public function tag(): string {
		return self::TYPE . '_' . self::NAME;
	}

	/**
	 * @return string
	 */
	public function route(): string {
		return "extension/{$this->name()}/{$this->type()}/{$this->name()}";
	}

	/**
	 * @return string
	 */
	public function model(): string {
		return 'model_' . str_replace('/', '_', $this->route());
	}

	/**
	 * @return bool
	 */
	public function status(): bool {
		return (bool)$this->config->get("{$this->tag()}_status");
	}

	/**
	 * @param string $key
	 *
	 * @return mixed
	 */
	public function config() {
		return $this->config->get("{$this->tag()}");
	}
}
