<?php

/*
@name     OpenCart
@package  Library Decorator
@author   ocmod.space, <ocmod.space@gmail.com>
@version  1.0.0
@link     https://github.com/ocmod-space/ocmod-library-decorator
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/ocmod-library-decorator
@license  https://raw.githubusercontent.com/ocmod-space/ocmod-library-decorator/main/LICENSE.txt
*/

class ControllerExtensionModuleLibraryDecorator extends Controller {
	private $mod;
	private $lib;
	private $cfg;

	/**
	 * @param mixed $registry
	 */
	public function __construct(Registry $registry) {
		parent::__construct($registry);

		$name = pathinfo(__FILE__, PATHINFO_FILENAME);

		require_once DIR_SYSTEM . "library/ocmod_space/{$name}/module.php";
		$this->mod = new \OcmodSpace\LibraryDecorator\Module($registry);

		$this->cfg = $this->mod->config();
	}

	/**
	 * @param string $route
	 * @param mixed  $data
	 *
	 * @return void
	 */
	public function libraryDecorator(string &$route, &$data): void {
		if (!$this->mod->status()) {
			return;
		}

		$path_suffix = "library/ocmod_space/{$this->mod->name()}";
		require_once(DIR_SYSTEM . "{$path_suffix}/abstract_decorator.php");

		$map = [
			'cart' => \OcmodSpace\LibraryDecorator\CartDecorator::class,
			'tax'  => \OcmodSpace\LibraryDecorator\TaxDecorator::class,
		];

		foreach ($map as $key => $class) {
			$file = DIR_SYSTEM . "{$path_suffix}/" . strtolower($key) . '_decorator.php';

			if (is_file($file)) {
				require_once($file);
			}

			if (!($this->registry->get($key) instanceof $class)) {
				$this->registry->set($key, new $class($this->registry));
			}
		}
	}
}
