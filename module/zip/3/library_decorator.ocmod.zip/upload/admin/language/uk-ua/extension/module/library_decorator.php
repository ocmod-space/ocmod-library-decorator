<?php

/*
@name     OpenCart
@package  Library Decorator
@author   ocmod.space, <ocmod.space@gmail.com>
@version  1.0.0
@link     https://github.com/ocmod-space/ocmod-library-decorator
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/ocmod-library-decorator
@license  https://raw.githubusercontent.com/ocmod-space/ocmod-library-decorator/main/LICENSE.txt
*/

$_['heading_title'] = '/<a href="https://www.ocmod.space/" target="_blank">ocmod.space</a>/library_decorator';
$_['text_extension'] = 'Розширення';
$_['text_edit'] = 'Редагування параметрів модуля <b>Library Decorator</b>';
$_['text_success'] = 'Готово! Параметри модуля <b>Library Decorator</b> збережено.';
$_['error_permission'] = 'Увага! Недостатньо прав для редагування параметрів модуля<b>Library Decorator</b>!';
$_['text_made'] = '<code>Зроблено з <i class="fa fa-heart" aria-hidden="true" style="background: linear-gradient(to bottom, #0057b7 50%, #ffd700 50%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; font-size: 18px;"></i> в Україні</code>';

$_['text_about'] = 'Бібліотечний декоратор для перехоплення подій, повʼязаних з <code>cart</code> та <code>tax</code>, а також для додавання власного функціоналу.';

$_['entry_status'] = 'Статус';
