<?php

/*
@name     OpenCart
@package  Library Decorator
@author   ocmod.space, <ocmod.space@gmail.com>
@version  1.0.0
@link     https://github.com/ocmod-space/ocmod-library-decorator
@link     https://www.opencart.com/index.php?route=marketplace/extension&filter_member=ocmod.space
@link     https://github.com/ocmod-space/ocmod-library-decorator
@license  https://raw.githubusercontent.com/ocmod-space/ocmod-library-decorator/main/LICENSE.txt
*/

namespace OcmodSpace\LibraryDecorator;

class CartDecorator extends AbstractDecorator {
	public function __construct($registry) {
		$class = 'Cart\\Cart';

		parent::__construct($registry, $class, 'library/cart/cart');
	}
}
